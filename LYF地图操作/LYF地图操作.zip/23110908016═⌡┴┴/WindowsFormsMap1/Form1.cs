﻿using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Controls;
using ESRI.ArcGIS.Display;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.Geometry;
using ESRI.ArcGIS.Output;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsMap1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // ================= 第6章 编辑变量 =================
        // [重构] 使用 Helper 类接管
        private EditorHelper _editorHelper;
        private MeasureHelper _measureHelper;
        private LayoutHelper _layoutHelper; // [新增]

        // 编辑用的反馈对象 (为了不和测量冲突，单独定义)
        // [移除] 移入 EditorHelper




        // [新增] 工具栏
        private ToolStrip toolStripMain;

        // [重构] 统一工具管理枚举
        private enum MapToolMode
        {
            None,
            Pan,
            MeasureDistance,
            MeasureArea,
            CreateFeature
        }
        private MapToolMode _currentToolMode = MapToolMode.None;

        // [重构] 切换工具的方法 (核心优化)
        private void SwitchTool(MapToolMode mode)
        {
            // 1. 清理旧工具的状态
            _measureHelper.Stop();
            _editorHelper.StopCreateFeature();

            // 刷新前景清除残影
            (axMapControl2.Map as IActiveView).PartialRefresh(esriViewDrawPhase.esriViewForeground, null, null);

            // 2. 设置新模式
            _currentToolMode = mode;

            // 3. 设置鼠标样式和引擎工具
            axMapControl2.CurrentTool = null; // 先重置
            axMapControl2.MousePointer = esriControlsMousePointer.esriPointerArrow; // [修复] 强制重置光标为箭头

            switch (mode)
            {
                case MapToolMode.Pan:
                    axMapControl2.MousePointer = esriControlsMousePointer.esriPointerPan;
                    // 如果希望使用引擎自带漫游，也可以 axMapControl2.Pan(); 但那是单次操作。
                    // 这里的 Pan 模式我们可能需要手动在 MouseMove/Down 里实现，或者直接调用 Pan() 
                    // 之前的代码是在 OnMouseDown 里调用的 Pan()，所以这里只变鼠标
                    break;
                case MapToolMode.MeasureDistance:
                    _measureHelper.StartMeasureDistance();
                    break;
                case MapToolMode.MeasureArea:
                    _measureHelper.StartMeasureArea();
                    break;
                case MapToolMode.CreateFeature:
                    _editorHelper.StartCreateFeature();
                    break;
                default:
                    axMapControl2.MousePointer = esriControlsMousePointer.esriPointerArrow;
                    break;
            }
        }
        // ================================================

        private void Form1_Load(object sender, EventArgs e)
        {
            // 初始化 Helper
            _measureHelper = new MeasureHelper(axMapControl2);
            _editorHelper = new EditorHelper(axMapControl2);
            // [新增] 布局 Helper (注意需要传入 axPageLayoutControl1, 假设用户已添加并命名正确)
            // 如果 axPageLayoutControl1 报错，请检查控件名称是否为 axPageLayoutControl1
            _layoutHelper = new LayoutHelper(this.axPageLayoutControl1, this.axMapControl2);

            // [重构] UIHelper 菜单已迁移到 Designer.cs
            // UIHelper uiHelper = new UIHelper(this, axMapControl2, menuStrip1);
            // uiHelper.Initialize();

            // 绑定 TOC 右键事件
            axTOCControl2.OnMouseDown += AxTOCControl2_OnMouseDown;

            // [新增] 显式绑定 Buddy Control，防止设计器丢失连接
            axTOCControl2.SetBuddyControl(axMapControl2);

            // [新增] 绑定 TabControl 切换事件
            this.tabControl1.SelectedIndexChanged += TabControl1_SelectedIndexChanged;
        }

        private void TabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // 当切换到布局视图 (Index = 1，或者根据名字判断) 时，同步数据
            if (tabControl1.SelectedTab.Text.Contains("布局") || tabControl1.SelectedIndex == 1)
            {
                MessageBox.Show("正在同步地图数据到布局视图...");
                _layoutHelper.SynchronizeMap();
            }
        }

        // ================= 第8章 布局视图 =================

        public void ItemAddNorthArrow_Click(object sender, EventArgs e)
        {
            _layoutHelper.AddNorthArrow();
        }

        public void ItemAddXYData_Click(object sender, EventArgs e)
        {
            FormAddXYData frm = new FormAddXYData(axMapControl2);
            frm.ShowDialog();
        }

        public void ItemAddScaleBar_Click(object sender, EventArgs e)
        {
            _layoutHelper.AddScaleBar();
        }

        public void ItemAddLegend_Click(object sender, EventArgs e)
        {
            _layoutHelper.AddLegend();
        }

        // ================================================

        // TOC 右键菜单逻辑
        private void AxTOCControl2_OnMouseDown(object sender, ITOCControlEvents_OnMouseDownEvent e)
        {
            if (e.button != 2) return; // 2 = Right Click

            esriTOCControlItem item = esriTOCControlItem.esriTOCControlItemNone;
            IBasicMap map = null;
            ILayer layer = null;
            object other = null;
            object index = null;

            axTOCControl2.HitTest(e.x, e.y, ref item, ref map, ref layer, ref other, ref index);

            if (item == esriTOCControlItem.esriTOCControlItemLayer && layer != null)
            {
                // 创建右键菜单
                ContextMenuStrip contextMenu = new ContextMenuStrip();

                // 1. 属性 (打开符号化窗体)
                ToolStripMenuItem propItem = new ToolStripMenuItem("属性 (符号化/透明度)");
                propItem.Click += (s, ev) =>
                {
                    FormSymbolize frm = new FormSymbolize(this.axMapControl2, this.axTOCControl2);
                    frm.Show(); // 实际上应该让他自动选中当前layer，这里简化处理
                };
                contextMenu.Items.Add(propItem);

                // 2. 移除图层
                ToolStripMenuItem removeItem = new ToolStripMenuItem("移除图层");
                removeItem.Click += (s, ev) =>
                {
                    axMapControl2.Map.DeleteLayer(layer);
                    axMapControl2.ActiveView.Refresh();
                    axTOCControl2.Update();
                };
                contextMenu.Items.Add(removeItem);

                // 3. 缩放到图层
                ToolStripMenuItem zoomItem = new ToolStripMenuItem("缩放到图层");
                zoomItem.Click += (s, ev) =>
                {
                    if (layer is IGeoDataset)
                    {
                        axMapControl2.Extent = (layer as IGeoDataset).Extent;
                        axMapControl2.ActiveView.Refresh();
                    }
                };
                contextMenu.Items.Add(zoomItem);

                // 显示菜单
                contextMenu.Show(axTOCControl2, e.x, e.y);
            }
        }

        // [已移除] AddCustomMenuItems 方法，已移入 UIHelper.cs


        // ================= 第5章 事件处理 =================

        public void ItemDataQuery_Click(object sender, EventArgs e)
        {
            DataoSourceForm frm = new DataoSourceForm();
            frm.CurrentMap = axMapControl2.Map;
            frm.Show();
        }

        public void ItemSymbolize_Click(object sender, EventArgs e)
        {
            // 打开符号化窗体
            FormSymbolize frm = new FormSymbolize(this.axMapControl2, this.axTOCControl2);
            frm.Show(); // 非模态，方便调节
        }

        public void ItemExport_Click(object sender, EventArgs e)
        {
            // 地图导出
            try
            {
                SaveFileDialog saveFileDialog = new SaveFileDialog();
                saveFileDialog.Filter = "JPEG Image (*.jpg)|*.jpg|Bitmap Image (*.bmp)|*.bmp|PNG Image (*.png)|*.png";
                saveFileDialog.Title = "导出地图";
                saveFileDialog.FileName = "MapExport.jpg";

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string fileName = saveFileDialog.FileName;
                    IActiveView activeView = axMapControl2.ActiveView;
                    IExport export = null;

                    if (fileName.EndsWith(".jpg"))
                    {
                        export = new ExportJPEGClass();
                    }
                    else if (fileName.EndsWith(".bmp"))
                    {
                        export = new ExportBMPClass();
                    }
                    else if (fileName.EndsWith(".png"))
                    {
                        export = new ExportPNGClass();
                    }
                    else
                    {
                        export = new ExportJPEGClass();
                    }

                    export.ExportFileName = fileName;
                    export.Resolution = 96; // DPI
                    tagRECT exportRect;
                    exportRect.left = 0;
                    exportRect.top = 0;
                    exportRect.right = activeView.ExportFrame.right;
                    exportRect.bottom = activeView.ExportFrame.bottom;

                    // 获取 HDC
                    int hdc = export.StartExporting();
                    activeView.Output(hdc, (int)export.Resolution, ref exportRect, null, null);
                    export.FinishExporting();
                    export.Cleanup();

                    MessageBox.Show("导出成功！路径：" + fileName);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("导出失败：" + ex.Message);
            }
        }

        // ================= 第6章 事件处理 =================

        public void ItemStartEdit_Click(object sender, EventArgs e)
        {
            if (axMapControl2.LayerCount == 0) return;

            // 使用对话框选择图层
            FormStartEdit formStart = new FormStartEdit(this.axMapControl2);
            if (formStart.ShowDialog() == DialogResult.OK)
            {
                IFeatureLayer targetLayer = formStart.SelectedLayer;
                if (targetLayer == null) return;

                IDataset dataset = targetLayer.FeatureClass as IDataset;
                IWorkspace workspace = dataset.Workspace;

                if (workspace.Type == esriWorkspaceType.esriFileSystemWorkspace ||
                    workspace.Type == esriWorkspaceType.esriLocalDatabaseWorkspace)
                {
                    _editorHelper.StartEditing(targetLayer);
                }
                else
                {
                    MessageBox.Show("不支持的工作空间类型 (仅支持 Shapefile/GDB)。");
                }
            }
        }

        public void ItemUndo_Click(object sender, EventArgs e)
        {
            _editorHelper.Undo();
        }

        public void ItemSaveEdit_Click(object sender, EventArgs e)
        {
            _editorHelper.SaveEdit();
        }

        public void ItemStopEdit_Click(object sender, EventArgs e)
        {
            _editorHelper.StopEditing();
            SwitchTool(MapToolMode.None);
        }

        public void ItemCreateFeature_Click(object sender, EventArgs e)
        {
            SwitchTool(MapToolMode.CreateFeature);
        }

        private void 加载地图文档ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog openFileDialog = new OpenFileDialog();
                openFileDialog.CheckFileExists = true;
                openFileDialog.Title = "打开地图文档";
                openFileDialog.Filter = "ArcMap文档(*.mxd)|*.mxd;|ArcMap模板(*.mxt)|" +
                    "*.mxt|发布地图文件(*.pmf)|*.pmf|" +
                    "所有地图格式(*.mxd;*.mxt;*.pmf)|*.mxd;*.mxt;*.pmf";
                openFileDialog.Multiselect = false;
                openFileDialog.RestoreDirectory = true;
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string pFileName = openFileDialog.FileName;
                    if (string.IsNullOrEmpty(pFileName))
                    {
                        return;
                    }
                    if (this.axMapControl2.CheckMxFile(pFileName))
                    {
                        this.axMapControl2.LoadMxFile(pFileName);

                        // [Fix] 显式刷新 ActiveView 和 TOC
                        this.axMapControl2.ActiveView.Refresh();
                        this.axTOCControl2.Update();

                        // [新增] 检查图层链接是否断裂
                        CheckBrokenLayers(axMapControl2.Map);
                    }
                    else
                    {
                        MessageBox.Show(pFileName + "是无效的地图文档！", "信息提示");
                        return;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("加载地图文档时发生错误: " + ex.Message, "错误提示");
            }
        }

        // [新增] 检查并报告无效图层 (红色感叹号)
        private void CheckBrokenLayers(IMap map)
        {
            if (map == null) return;
            List<string> brokenLayerNames = new List<string>();

            // 遍历图层 (第一层级)
            for (int i = 0; i < map.LayerCount; i++)
            {
                ILayer layer = map.get_Layer(i);
                if (!layer.Valid)
                {
                    brokenLayerNames.Add(layer.Name);
                }

                // 如果是复合图层，还可以递归检查，这里暂查第一层
            }

            if (brokenLayerNames.Count > 0)
            {
                string msg = "警告：以下图层数据丢失（显示红色感叹号），请修复数据源：\n\n";
                foreach (string name in brokenLayerNames)
                {
                    msg += "- " + name + "\n";
                }
                MessageBox.Show(msg, "数据丢失警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void 加载shp数据ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog openFileDialog = new OpenFileDialog();
                openFileDialog.CheckFileExists = true;
                openFileDialog.Title = "打开Shapefile数据";
                openFileDialog.Filter = "Shapefile文件(*.shp)|*.shp";
                openFileDialog.Multiselect = false; // 支持单选，如需多选可改为true遍历
                openFileDialog.RestoreDirectory = true;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string fullPath = openFileDialog.FileName;
                    string pathName = System.IO.Path.GetDirectoryName(fullPath);
                    string fileName = System.IO.Path.GetFileNameWithoutExtension(fullPath);

                    // 使用 AddShapeFile 直接添加
                    axMapControl2.AddShapeFile(pathName, fileName);

                    // 刷新视图
                    axMapControl2.ActiveView.Refresh();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("加载SHP数据时发生错误: " + ex.Message, "错误提示");
            }
        }

        // 不是必须的，因为 Helper 会管理
        // private FormMeasureResult formMeasureResult = null; 

        // --- 测量变量 (精简后) ---
        // [移除] 移入 MeasureHelper

        // 面积测量菜单点击
        private void tsmiAreaMeasure_Click(object sender, EventArgs e)
        {
            SwitchTool(MapToolMode.MeasureArea);
        }

        // 双击事件：结束测量 OR 结束要素绘制
        public void axMapControl1_OnDoubleClick(object sender, IMapControlEvents2_OnDoubleClickEvent e)
        {
            switch (_currentToolMode)
            {
                case MapToolMode.CreateFeature:
                    _editorHelper.OnDoubleClick();
                    break;
                case MapToolMode.MeasureArea:
                    _measureHelper.OnDoubleClick();
                    // 测量结束后是否要切回 None? Helper 内部会 Stop，但不改 Mode。
                    // 最好在这里切回 Arrow
                    SwitchTool(MapToolMode.None);
                    break;
                case MapToolMode.MeasureDistance:
                    _measureHelper.OnDoubleClick();
                    SwitchTool(MapToolMode.None);
                    break;
            }
        }

        // [移除] 抽取的双击处理方法 (已移入 helper)

        // 鼠标按下事件 (重构后)
        private void axMapControl2_OnMouseDown(object sender, IMapControlEvents2_OnMouseDownEvent e)
        {
            if (e.button != 1) return; // 只处理左键

            // 路由到 Helper
            switch (_currentToolMode)
            {
                case MapToolMode.Pan:
                    axMapControl2.Pan();
                    break;
                case MapToolMode.CreateFeature:
                    _editorHelper.OnMouseDown(e.x, e.y);
                    break;
                case MapToolMode.MeasureDistance:
                case MapToolMode.MeasureArea:
                    _measureHelper.OnMouseDown(e.x, e.y);
                    break;
            }
        }

        // [移除] 抽取的 CreateFeature/Measure 处理方法

        private void axMapControl1_OnMouseMove(object sender, IMapControlEvents2_OnMouseMoveEvent e)
        {
            // 路由到 Helper
            switch (_currentToolMode)
            {
                case MapToolMode.CreateFeature:
                    _editorHelper.OnMouseMove(e.x, e.y);
                    break;
                case MapToolMode.MeasureDistance:
                case MapToolMode.MeasureArea:
                    _measureHelper.OnMouseMove(e.x, e.y);
                    break;
            }
        }

        // 漫游按钮
        public void 漫游ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SwitchTool(MapToolMode.Pan);
        }

        // 刷新至初始视图
        public void 刷新至初始视图ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (axMapControl2 == null) return;
            axMapControl2.Extent = axMapControl2.FullExtent;
        }

        // 清除选择集
        private void 清除选择集ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (axMapControl2.Map == null) return;

            // 1. 清除内部记录
            axMapControl2.Map.ClearSelection();

            // 2. 【关键修改】直接使用控件的 ActiveView 进行刷新
            // 参数1: esriViewGeoSelection 代表只刷新“高亮选择”层，不重绘地图，速度极快
            axMapControl2.ActiveView.PartialRefresh(esriViewDrawPhase.esriViewGeoSelection, null, null);

            // 3. 恢复鼠标
            axMapControl2.MousePointer = ESRI.ArcGIS.Controls.esriControlsMousePointer.esriPointerArrow;

            // 4. 关闭其他功能开关
            SwitchTool(MapToolMode.None);

            // 提示（觉得烦可以注释掉）
            MessageBox.Show("已清除选择！");
        }

        // 面积量测菜单（你之前的）
        private void 面积量测ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // 复用上面写好的 tsmiAreaMeasure_Click 逻辑
            tsmiAreaMeasure_Click(sender, e);
        }

        // 【新增】距离量测菜单
        // 如果你的界面上有这个按钮，请在事件属性里绑定到这个方法
        private void 距离量测ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SwitchTool(MapToolMode.MeasureDistance);
        }

        // 数据查询
        public void 数据查询ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DataoSourceForm datasourcefrm = new DataoSourceForm();
            datasourcefrm.CurrentMap = axMapControl2.Map;
            datasourcefrm.Show();
        }

        // 空间查询
        public void 空间查询ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormSelectByLocation frmSelectByLocation = new FormSelectByLocation();
            frmSelectByLocation.CurrentMap = axMapControl2.Map;
            frmSelectByLocation.Show();
        }

        // 查询菜单（你原来的代码）
        private void 查询ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormSelectByLocation frmSelectByLocation = new FormSelectByLocation();
            frmSelectByLocation.CurrentMap = axMapControl2.Map;
            frmSelectByLocation.Show();
        }

        // 另存为
        private void 另存为ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                SaveFileDialog pSaveFileDialog = new SaveFileDialog();
                pSaveFileDialog.Title = "另存为";
                pSaveFileDialog.OverwritePrompt = true;
                pSaveFileDialog.Filter = "ArcMap 文档(*.mxd)|*.mxd|ArcMap 模板(*.mxt)|*.mxt";
                pSaveFileDialog.RestoreDirectory = true;
                if (pSaveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string sFilePath = pSaveFileDialog.FileName;
                    IMapDocument pMapDocument = new MapDocumentClass();
                    pMapDocument.New(sFilePath);
                    pMapDocument.ReplaceContents(axMapControl2.Map as IMxdContents);
                    pMapDocument.Save(true, true);
                    pMapDocument.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void toolStripStatusLabel1_Click(object sender, EventArgs e) { }
        private void axLicenseControl1_Enter(object sender, EventArgs e) { }

        public void 动态标注ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // ... (existing code)
            FormLabeling frmLabel = new FormLabeling();
            frmLabel.CurrentMap = axMapControl2.Map;
            frmLabel.ShowDialog();
        }

        // ================= 第7章 空间分析 =================

        public void ItemBuffer_Click(object sender, EventArgs e)
        {
            FormBuffer frm = new FormBuffer(axMapControl2);
            frm.ShowDialog();
        }

        public void ItemOverlay_Click(object sender, EventArgs e)
        {
            FormOverlay frm = new FormOverlay(axMapControl2);
            frm.ShowDialog();
        }
    }
}
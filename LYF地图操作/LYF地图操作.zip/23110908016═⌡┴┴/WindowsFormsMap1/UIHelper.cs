using System;
using System.Drawing;
using System.Windows.Forms;
using ESRI.ArcGIS.Controls;

namespace WindowsFormsMap1
{
    /// <summary>
    /// UI 辅助类
    /// 负责初始化工具栏和自定义菜单
    /// 避免 Form1 代码过于臃肿
    /// </summary>
    public class UIHelper
    {
        private Form1 _form;
        private AxMapControl _mapControl;
        private MenuStrip _menuStrip;

        public UIHelper(Form1 form, AxMapControl mapControl, MenuStrip menuStrip)
        {
            _form = form;
            _mapControl = mapControl;
            _menuStrip = menuStrip;
        }

        public void Initialize()
        {
            InitializeToolbar();
            AddCustomMenuItems();
        }

        private void InitializeToolbar()
        {
            ToolStrip toolStripMain = new ToolStrip();
            toolStripMain.Dock = DockStyle.Top;
            toolStripMain.ImageScalingSize = new System.Drawing.Size(24, 24);

            // --- 地图浏览组 ---
            toolStripMain.Items.Add(new ToolStripLabel("【浏览】"));

            ToolStripButton btnPan = new ToolStripButton("漫游");
            btnPan.Click += _form.漫游ToolStripMenuItem_Click;
            toolStripMain.Items.Add(btnPan);

            ToolStripButton btnFullExtent = new ToolStripButton("全图");
            btnFullExtent.Click += _form.刷新至初始视图ToolStripMenuItem_Click;
            toolStripMain.Items.Add(btnFullExtent);

            toolStripMain.Items.Add(new ToolStripSeparator());

            // --- 制图组 ---
            toolStripMain.Items.Add(new ToolStripLabel("【制图】"));

            ToolStripButton btnSymbolize = new ToolStripButton("符号化");
            btnSymbolize.Click += _form.ItemSymbolize_Click;
            toolStripMain.Items.Add(btnSymbolize);

            ToolStripButton btnExport = new ToolStripButton("导出地图");
            btnExport.Click += _form.ItemExport_Click;
            toolStripMain.Items.Add(btnExport);

            toolStripMain.Items.Add(new ToolStripSeparator());

            // --- 编辑组 ---
            toolStripMain.Items.Add(new ToolStripLabel("【编辑】"));

            ToolStripButton btnStartEdit = new ToolStripButton("开始编辑");
            btnStartEdit.Click += _form.ItemStartEdit_Click;
            toolStripMain.Items.Add(btnStartEdit);

            ToolStripButton btnCreate = new ToolStripButton("创建要素");
            btnCreate.Click += _form.ItemCreateFeature_Click;
            toolStripMain.Items.Add(btnCreate);

            ToolStripButton btnUndo = new ToolStripButton("撤销");
            btnUndo.Click += _form.ItemUndo_Click;
            toolStripMain.Items.Add(btnUndo);

            ToolStripButton btnSave = new ToolStripButton("保存");
            btnSave.Click += _form.ItemSaveEdit_Click;
            toolStripMain.Items.Add(btnSave);

            ToolStripButton btnStop = new ToolStripButton("结束");
            btnStop.Click += _form.ItemStopEdit_Click;
            toolStripMain.Items.Add(btnStop);

            _form.Controls.Add(toolStripMain);
            // 调整顺序
            _menuStrip.SendToBack();
            toolStripMain.BringToFront();
        }

        private void AddCustomMenuItems()
        {
            // 1. 地图制图菜单
            ToolStripMenuItem menuMapping = new ToolStripMenuItem("地图制图");

            ToolStripMenuItem itemSymbolize = new ToolStripMenuItem("符号化与特效(5.2/5.4)");
            itemSymbolize.Click += _form.ItemSymbolize_Click;
            menuMapping.DropDownItems.Add(itemSymbolize);

            ToolStripMenuItem itemExport = new ToolStripMenuItem("地图导出(5.8)");
            itemExport.Click += _form.ItemExport_Click;
            menuMapping.DropDownItems.Add(itemExport);

            ToolStripMenuItem itemLabel = new ToolStripMenuItem("动态标注");
            itemLabel.Click += _form.动态标注ToolStripMenuItem_Click;
            menuMapping.DropDownItems.Add(itemLabel);

            _menuStrip.Items.Add(menuMapping);

            // 2. 查询统计菜单
            ToolStripMenuItem menuQuery = new ToolStripMenuItem("查询统计");

            ToolStripMenuItem itemDataQuery = new ToolStripMenuItem("数据查询");
            itemDataQuery.Click += _form.数据查询ToolStripMenuItem_Click;
            menuQuery.DropDownItems.Add(itemDataQuery);

            ToolStripMenuItem itemSpatialQuery = new ToolStripMenuItem("空间查询");
            itemSpatialQuery.Click += _form.空间查询ToolStripMenuItem_Click;
            menuQuery.DropDownItems.Add(itemSpatialQuery);

            _menuStrip.Items.Add(menuQuery);

            // 3. 空间分析菜单 (第7章)
            ToolStripMenuItem menuAnalysis = new ToolStripMenuItem("空间分析");

            ToolStripMenuItem itemBuffer = new ToolStripMenuItem("缓冲区分析");
            itemBuffer.Click += _form.ItemBuffer_Click;
            menuAnalysis.DropDownItems.Add(itemBuffer);

            ToolStripMenuItem itemOverlay = new ToolStripMenuItem("叠置分析");
            itemOverlay.Click += _form.ItemOverlay_Click;
            menuAnalysis.DropDownItems.Add(itemOverlay);

            _menuStrip.Items.Add(menuAnalysis);

            // 4. 布局制图菜单 (第8章)
            ToolStripMenuItem menuLayout = new ToolStripMenuItem("版面设计");

            ToolStripMenuItem itemNorthArrow = new ToolStripMenuItem("添加指北针");
            itemNorthArrow.Click += _form.ItemAddNorthArrow_Click;
            menuLayout.DropDownItems.Add(itemNorthArrow);

            ToolStripMenuItem itemScaleBar = new ToolStripMenuItem("添加比例尺");
            itemScaleBar.Click += _form.ItemAddScaleBar_Click;
            menuLayout.DropDownItems.Add(itemScaleBar);

            ToolStripMenuItem itemLegend = new ToolStripMenuItem("添加图例");
            itemLegend.Click += _form.ItemAddLegend_Click;
            menuLayout.DropDownItems.Add(itemLegend);

            _menuStrip.Items.Add(menuLayout);

            // 5. 空间数据编辑菜单
            ToolStripMenuItem menuEditing = new ToolStripMenuItem("空间数据编辑");

            ToolStripMenuItem itemStartEdit = new ToolStripMenuItem("开始编辑(6.3)");
            itemStartEdit.Click += _form.ItemStartEdit_Click;
            menuEditing.DropDownItems.Add(itemStartEdit);

            ToolStripMenuItem itemSaveEdit = new ToolStripMenuItem("保存编辑(6.9)");
            itemSaveEdit.Click += _form.ItemSaveEdit_Click;
            menuEditing.DropDownItems.Add(itemSaveEdit);

            ToolStripMenuItem itemStopEdit = new ToolStripMenuItem("结束编辑(6.10)");
            itemStopEdit.Click += _form.ItemStopEdit_Click;
            menuEditing.DropDownItems.Add(itemStopEdit);

            menuEditing.DropDownItems.Add(new ToolStripSeparator());

            ToolStripMenuItem itemCreateFeature = new ToolStripMenuItem("创建要素工具(6.6)");
            itemCreateFeature.Click += _form.ItemCreateFeature_Click;
            menuEditing.DropDownItems.Add(itemCreateFeature);

            ToolStripMenuItem itemUndo = new ToolStripMenuItem("撤销操作 (Ctrl+Z)");
            itemUndo.ShortcutKeys = Keys.Control | Keys.Z;
            itemUndo.Click += _form.ItemUndo_Click;
            menuEditing.DropDownItems.Add(itemUndo);

            _menuStrip.Items.Add(menuEditing);

            // 清理重复项
            foreach (ToolStripItem item in _menuStrip.Items)
            {
                if ((item.Text == "动态标注" || item.Text.Contains("查询")) && item.Text != "查询统计")
                {
                    item.Visible = false;
                }
            }
        }
    }
}

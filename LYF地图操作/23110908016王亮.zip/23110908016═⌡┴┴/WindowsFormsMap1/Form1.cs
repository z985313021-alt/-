﻿using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Controls;
using ESRI.ArcGIS.Display;
using ESRI.ArcGIS.Geometry;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsMap1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // 窗体加载时的初始化代码
        }

        private void 加载地图文档ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog openFileDialog = new OpenFileDialog();
                openFileDialog.CheckFileExists = true;
                openFileDialog.Title = "打开地图文档";
                openFileDialog.Filter = "ArcMap文档(*.mxd)|*.mxd;|ArcMap模板(*.mxt)|" +
                    "*.mxt|发布地图文件(*.pmf)|*.pmf|" +
                    "所有地图格式(*.mxd;*.mxt;*.pmf)|*.mxd;*.mxt;*.pmf";
                openFileDialog.Multiselect = false;
                openFileDialog.RestoreDirectory = true;
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string pFileName = openFileDialog.FileName;
                    if (string.IsNullOrEmpty(pFileName))
                    {
                        return;
                    }
                    if (this.axMapControl2.CheckMxFile(pFileName))
                    {
                        this.axMapControl2.LoadMxFile(pFileName);
                    }
                    else
                    {
                        MessageBox.Show(pFileName + "是无效的地图文档！", "信息提示");
                        return;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("加载地图文档时发生错误: " + ex.Message, "错误提示");
            }
        }

        private FormMeasureResult formMeasureResult = null;    //量算结果窗体

        // --- 距离量算相关变量 ---
        private bool isMeasuringDistance = false;              // 【关键修改】新增开关：是否正在测距离
        private INewLineFeedback newLineFeedback;              // 追踪线对象
        private IPoint currentPoint = null;                    // 鼠标点击点
        private IPoint movePt = null;                          // 鼠标移动时的当前点
        private double dToltalLength = 0;                      // 量测总长度
        private double dSegmentLength = 0;                     // 片段距离
        private bool isPanning = false;

        // --- 面积量算相关变量 ---
        private bool isMeasuringArea = false;
        private INewPolygonFeedback newPolygonFeedback;


        // 面积测量菜单点击
        private void tsmiAreaMeasure_Click(object sender, EventArgs e)
        {
            // 1. 关闭距离测量，开启面积测量
            isMeasuringDistance = false;
            isMeasuringArea = true;

            // 2. 清理可能残留的距离线
            if (newLineFeedback != null)
            {
                newLineFeedback.Stop();
                newLineFeedback = null;
                (axMapControl2.Map as IActiveView).PartialRefresh(esriViewDrawPhase.esriViewForeground, null, null);
            }

            // 3. 更改鼠标样式
            this.axMapControl2.MousePointer = esriControlsMousePointer.esriPointerCrosshair;

            // 4. 显示结果窗体
            if (formMeasureResult == null || formMeasureResult.IsDisposed)
            {
                formMeasureResult = new FormMeasureResult();
                formMeasureResult.Show();
            }
            else
            {
                formMeasureResult.Activate();
            }
            formMeasureResult.lblResultMeasure.Text = "请在地图上点击绘制多边形...";
        }

        // 双击事件：结束测量
        public void axMapControl1_OnDoubleClick(object sender, IMapControlEvents2_OnDoubleClickEvent e)
        {
            // --- 面积量算结束逻辑 ---
            if (isMeasuringArea && newPolygonFeedback != null)
            {
                IPolygon polygon = newPolygonFeedback.Stop();
                newPolygonFeedback = null; // 重置
                isMeasuringArea = false;   // 结束模式
                axMapControl2.MousePointer = esriControlsMousePointer.esriPointerArrow;

                if (polygon != null && !polygon.IsEmpty)
                {
                    (polygon as ITopologicalOperator).Simplify();
                    polygon.Close();
                    IArea area = polygon as IArea;
                    double measuredArea = Math.Abs(area.Area);

                    if (formMeasureResult != null)
                    {
                        formMeasureResult.lblResultMeasure.Text = string.Format("面积为: {0:F2} 平方米", measuredArea);
                    }
                }
                (axMapControl2.Map as IActiveView).PartialRefresh(esriViewDrawPhase.esriViewGeography, null, null);
                return;
            }

            // --- 距离量算结束逻辑 ---
            // 只有在开启测距模式下才执行
            if (isMeasuringDistance)
            {
                if (formMeasureResult != null)
                {
                    formMeasureResult.lblResultMeasure.Text = "线段总长度为：" + dToltalLength + this.axMapControl2.Map.MapUnits;
                }

                if (newLineFeedback != null)
                {
                    newLineFeedback.Stop();
                    newLineFeedback = null;

                    //清空所画的对象
                    (this.axMapControl2.Map as IActiveView).PartialRefresh(esriViewDrawPhase.esriViewForeground, null, null);
                }

                dToltalLength = 0;
                dSegmentLength = 0;
                isMeasuringDistance = false; // 结束测距
                axMapControl2.MousePointer = esriControlsMousePointer.esriPointerArrow;
            }
        }

        // 鼠标按下事件
        private void axMapControl2_OnMouseDown(object sender, IMapControlEvents2_OnMouseDownEvent e)
        {
            if (isPanning)
            {
                axMapControl2.Pan(); // 【关键】在这里调用 Pan，引擎会接管鼠标直到你松开
                return; // 漫游时不需要执行后面的测距逻辑
            }
            // 1. 面积测量
            if (isMeasuringArea)
            {
                IPoint clickedPoint = axMapControl2.ToMapPoint(e.x, e.y);
                if (newPolygonFeedback == null)
                {
                    newPolygonFeedback = new NewPolygonFeedbackClass();
                    newPolygonFeedback.Display = axMapControl2.ActiveView.ScreenDisplay;
                    newPolygonFeedback.Start(clickedPoint);
                }
                else
                {
                    newPolygonFeedback.AddPoint(clickedPoint);
                }
                return;
            }

            // 2. 距离量算
            // 【关键修改】只有在 isMeasuringDistance 为 true 时才执行，否则这就是漫游或其他操作
            if (isMeasuringDistance)
            {
                currentPoint = (this.axMapControl2.Map as IActiveView).ScreenDisplay.DisplayTransformation.ToMapPoint(e.x, e.y);

                if (newLineFeedback == null)
                {
                    newLineFeedback = new NewLineFeedbackClass();
                    newLineFeedback.Display = (axMapControl2.Map as IActiveView).ScreenDisplay;
                    newLineFeedback.Start(currentPoint);
                    dToltalLength = 0;
                }
                else
                {
                    newLineFeedback.AddPoint(currentPoint);
                }
                if (dSegmentLength != 0)
                {
                    dToltalLength = dToltalLength + dSegmentLength;
                }
            }
        }

        // 鼠标移动事件
        private void axMapControl1_OnMouseMove(object sender, IMapControlEvents2_OnMouseMoveEvent e)
        {
            // 【关键修改】只在测距离模式下计算，漫游模式下不执行这些
            if (isMeasuringDistance)
            {
                movePt = (this.axMapControl2.Map as IActiveView).ScreenDisplay.DisplayTransformation.ToMapPoint(e.x, e.y);

                if (newLineFeedback != null)
                {
                    newLineFeedback.MoveTo(movePt); // 应该是 movePt 而不是 currentPoint
                }

                double deltaX = 0;
                double deltaY = 0;

                if ((currentPoint != null) && (newLineFeedback != null))
                {
                    deltaX = movePt.X - currentPoint.X;
                    deltaY = movePt.Y - currentPoint.Y;
                    dSegmentLength = Math.Round(Math.Sqrt((deltaX * deltaX) + (deltaY * deltaY)), 3);
                    // 注意：这里的 dToltalLength 只是预览，不累加
                    double previewTotal = dToltalLength + dSegmentLength;

                    if (formMeasureResult != null)
                    {
                        formMeasureResult.lblResultMeasure.Text = String.Format(
                            "当前线段长度：{0:###.##} {1}\r\n总长度为：{2:###.##} {1}",
                            dSegmentLength, this.axMapControl2.Map.MapUnits, previewTotal);
                    }
                }
            }
        }

        // 漫游按钮
        private void 漫游ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (axMapControl2 == null) return;
            isPanning = true;
            // 1. 【关键】强制关闭所有测量开关
            isMeasuringDistance = false;//这两句并非漫游功能的主要代码，而是确保和测量功能不冲突所以选择强制关闭测量开关
            isMeasuringArea = false;

            // 2. 【关键】清理所有可能的绘图反馈对象   同样是确保功能不冲突
            if (newLineFeedback != null)
            {
                newLineFeedback.Stop();
                newLineFeedback = null;
            }
            if (newPolygonFeedback != null)
            {
                newPolygonFeedback.Stop();
                newPolygonFeedback = null;
            }
            // 刷新一次前景，擦除残影
            (axMapControl2.Map as IActiveView).PartialRefresh(esriViewDrawPhase.esriViewForeground, null, null);

            // 3. 改变鼠标样式为“小手”
            axMapControl2.MousePointer = ESRI.ArcGIS.Controls.esriControlsMousePointer.esriPointerPan;

            //
        }

        // 刷新至初始视图
        private void 刷新至初始视图ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (axMapControl2 == null) return;
            axMapControl2.Extent = axMapControl2.FullExtent;
        }

        // 清除选择集
        private void 清除选择集ToolStripMenuItem_Click(object sender, EventArgs e)
        { 
            if (axMapControl2.Map == null) return;

            // 1. 清除内部记录
            axMapControl2.Map.ClearSelection();

            // 2. 【关键修改】直接使用控件的 ActiveView 进行刷新
            // 参数1: esriViewGeoSelection 代表只刷新“高亮选择”层，不重绘地图，速度极快
            axMapControl2.ActiveView.PartialRefresh(esriViewDrawPhase.esriViewGeoSelection, null, null);

            // 3. 恢复鼠标
            axMapControl2.MousePointer = ESRI.ArcGIS.Controls.esriControlsMousePointer.esriPointerArrow;

            // 4. 关闭其他功能开关
            isMeasuringDistance = false;
            isMeasuringArea = false;
            isPanning = false;

            // 提示（觉得烦可以注释掉）
            MessageBox.Show("已清除选择！");
        }

        // 面积量测菜单（你之前的）
        private void 面积量测ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // 复用上面写好的 tsmiAreaMeasure_Click 逻辑
            tsmiAreaMeasure_Click(sender, e);
        }

        // 【新增】距离量测菜单
        // 如果你的界面上有这个按钮，请在事件属性里绑定到这个方法
        private void 距离量测ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // 1. 开启距离测量，关闭面积
            isMeasuringDistance = true;
            isMeasuringArea = false;

            // 2. 清理面积反馈
            if (newPolygonFeedback != null)
            {
                newPolygonFeedback.Stop();
                newPolygonFeedback = null;
                (axMapControl2.Map as IActiveView).PartialRefresh(esriViewDrawPhase.esriViewForeground, null, null);
            }

            // 3. 设置样式
            axMapControl2.MousePointer = esriControlsMousePointer.esriPointerCrosshair;

            // 4. 显示窗体
            if (formMeasureResult == null || formMeasureResult.IsDisposed)
            {
                formMeasureResult = new FormMeasureResult();
                formMeasureResult.Show();
            }
            else
            {
                formMeasureResult.Activate();
            }
            formMeasureResult.lblResultMeasure.Text = "请在地图上点击开始量算距离...";
        }

        // 数据查询
        private void 数据查询ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DataoSourceForm datasourcefrm = new DataoSourceForm();
            datasourcefrm.CurrentMap = axMapControl2.Map;
            datasourcefrm.Show();
        }

        // 空间查询
        private void 空间查询ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormSelectByLocation frmSelectByLocation = new FormSelectByLocation();
            frmSelectByLocation.CurrentMap = axMapControl2.Map;
            frmSelectByLocation.Show();
        }

        // 查询菜单（你原来的代码）
        private void 查询ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormSelectByLocation frmSelectByLocation = new FormSelectByLocation();
            frmSelectByLocation.CurrentMap = axMapControl2.Map;
            frmSelectByLocation.Show();
        }

        // 另存为
        private void 另存为ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                SaveFileDialog pSaveFileDialog = new SaveFileDialog();
                pSaveFileDialog.Title = "另存为";
                pSaveFileDialog.OverwritePrompt = true;
                pSaveFileDialog.Filter = "ArcMap 文档(*.mxd)|*.mxd|ArcMap 模板(*.mxt)|*.mxt";
                pSaveFileDialog.RestoreDirectory = true;
                if (pSaveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string sFilePath = pSaveFileDialog.FileName;
                    IMapDocument pMapDocument = new MapDocumentClass();
                    pMapDocument.New(sFilePath);
                    pMapDocument.ReplaceContents(axMapControl2.Map as IMxdContents);
                    pMapDocument.Save(true, true);
                    pMapDocument.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void toolStripStatusLabel1_Click(object sender, EventArgs e) { }
        private void axLicenseControl1_Enter(object sender, EventArgs e) { }

        private void 动态标注ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // 1. 检查地图是否为空
            if (axMapControl2.Map == null || axMapControl2.LayerCount == 0)
            {
                MessageBox.Show("当前没有加载任何图层！");
                return;
            }

            // 2. 实例化标注窗体
            FormLabeling frmLabel = new FormLabeling();

            // 3. 传递地图对象 (关键步骤)
            frmLabel.CurrentMap = axMapControl2.Map;

            // 4. 显示窗体 (建议用 ShowDialog 模态显示，即不关掉这个窗体不能点主窗体)
            frmLabel.ShowDialog();
        }
    }
}
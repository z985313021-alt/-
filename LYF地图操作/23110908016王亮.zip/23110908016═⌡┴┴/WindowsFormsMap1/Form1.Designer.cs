﻿
namespace WindowsFormsMap1
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.数据加载ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.加载地图文档ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.加载sho数据ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.查询ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.另存为ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.地图量测ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiAreaMeasure = new System.Windows.Forms.ToolStripMenuItem();
            this.面积量测ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.空间查询ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.数据查询ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.清除选择集ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.清楚选择集ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.刷新至初始视图ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.漫游ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.splitter2 = new System.Windows.Forms.Splitter();
            this.axTOCControl2 = new ESRI.ArcGIS.Controls.AxTOCControl();
            this.axMapControl2 = new ESRI.ArcGIS.Controls.AxMapControl();
            this.axLicenseControl3 = new ESRI.ArcGIS.Controls.AxLicenseControl();
            this.动态标注ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axTOCControl2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axMapControl2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axLicenseControl3)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.数据加载ToolStripMenuItem,
            this.地图量测ToolStripMenuItem,
            this.空间查询ToolStripMenuItem,
            this.数据查询ToolStripMenuItem,
            this.清除选择集ToolStripMenuItem,
            this.漫游ToolStripMenuItem,
            this.动态标注ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(711, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 数据加载ToolStripMenuItem
            // 
            this.数据加载ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.加载地图文档ToolStripMenuItem,
            this.加载sho数据ToolStripMenuItem,
            this.查询ToolStripMenuItem,
            this.另存为ToolStripMenuItem});
            this.数据加载ToolStripMenuItem.Name = "数据加载ToolStripMenuItem";
            this.数据加载ToolStripMenuItem.Size = new System.Drawing.Size(83, 24);
            this.数据加载ToolStripMenuItem.Text = "数据加载";
            // 
            // 加载地图文档ToolStripMenuItem
            // 
            this.加载地图文档ToolStripMenuItem.Name = "加载地图文档ToolStripMenuItem";
            this.加载地图文档ToolStripMenuItem.Size = new System.Drawing.Size(182, 26);
            this.加载地图文档ToolStripMenuItem.Text = "加载地图文档";
            this.加载地图文档ToolStripMenuItem.Click += new System.EventHandler(this.加载地图文档ToolStripMenuItem_Click);
            // 
            // 加载sho数据ToolStripMenuItem
            // 
            this.加载sho数据ToolStripMenuItem.Name = "加载sho数据ToolStripMenuItem";
            this.加载sho数据ToolStripMenuItem.Size = new System.Drawing.Size(182, 26);
            this.加载sho数据ToolStripMenuItem.Text = "加载shp数据";
            // 
            // 查询ToolStripMenuItem
            // 
            this.查询ToolStripMenuItem.Name = "查询ToolStripMenuItem";
            this.查询ToolStripMenuItem.Size = new System.Drawing.Size(182, 26);
            this.查询ToolStripMenuItem.Text = "空间查询";
            this.查询ToolStripMenuItem.Click += new System.EventHandler(this.查询ToolStripMenuItem_Click);
            // 
            // 另存为ToolStripMenuItem
            // 
            this.另存为ToolStripMenuItem.Name = "另存为ToolStripMenuItem";
            this.另存为ToolStripMenuItem.Size = new System.Drawing.Size(182, 26);
            this.另存为ToolStripMenuItem.Text = "另存为";
            this.另存为ToolStripMenuItem.Click += new System.EventHandler(this.另存为ToolStripMenuItem_Click);
            // 
            // 地图量测ToolStripMenuItem
            // 
            this.地图量测ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiAreaMeasure,
            this.面积量测ToolStripMenuItem});
            this.地图量测ToolStripMenuItem.Name = "地图量测ToolStripMenuItem";
            this.地图量测ToolStripMenuItem.Size = new System.Drawing.Size(83, 24);
            this.地图量测ToolStripMenuItem.Text = "地图量测";
            // 
            // tsmiAreaMeasure
            // 
            this.tsmiAreaMeasure.Name = "tsmiAreaMeasure";
            this.tsmiAreaMeasure.Size = new System.Drawing.Size(156, 26);
            this.tsmiAreaMeasure.Text = " 距离测量";
            this.tsmiAreaMeasure.Click += new System.EventHandler(this.距离量测ToolStripMenuItem_Click);
            // 
            // 面积量测ToolStripMenuItem
            // 
            this.面积量测ToolStripMenuItem.Name = "面积量测ToolStripMenuItem";
            this.面积量测ToolStripMenuItem.Size = new System.Drawing.Size(156, 26);
            this.面积量测ToolStripMenuItem.Text = "面积量测";
            this.面积量测ToolStripMenuItem.Click += new System.EventHandler(this.面积量测ToolStripMenuItem_Click);
            // 
            // 空间查询ToolStripMenuItem
            // 
            this.空间查询ToolStripMenuItem.Name = "空间查询ToolStripMenuItem";
            this.空间查询ToolStripMenuItem.Size = new System.Drawing.Size(83, 24);
            this.空间查询ToolStripMenuItem.Text = "空间查询";
            this.空间查询ToolStripMenuItem.Click += new System.EventHandler(this.空间查询ToolStripMenuItem_Click);
            // 
            // 数据查询ToolStripMenuItem
            // 
            this.数据查询ToolStripMenuItem.Name = "数据查询ToolStripMenuItem";
            this.数据查询ToolStripMenuItem.Size = new System.Drawing.Size(83, 24);
            this.数据查询ToolStripMenuItem.Text = "数据查询";
            this.数据查询ToolStripMenuItem.Click += new System.EventHandler(this.数据查询ToolStripMenuItem_Click);
            // 
            // 清除选择集ToolStripMenuItem
            // 
            this.清除选择集ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.清楚选择集ToolStripMenuItem,
            this.刷新至初始视图ToolStripMenuItem});
            this.清除选择集ToolStripMenuItem.Name = "清除选择集ToolStripMenuItem";
            this.清除选择集ToolStripMenuItem.Size = new System.Drawing.Size(53, 24);
            this.清除选择集ToolStripMenuItem.Text = "刷新";
            // 
            // 清楚选择集ToolStripMenuItem
            // 
            this.清楚选择集ToolStripMenuItem.Name = "清楚选择集ToolStripMenuItem";
            this.清楚选择集ToolStripMenuItem.Size = new System.Drawing.Size(167, 26);
            this.清楚选择集ToolStripMenuItem.Text = "清除选择集";
            this.清楚选择集ToolStripMenuItem.Click += new System.EventHandler(this.清除选择集ToolStripMenuItem_Click);
            // 
            // 刷新至初始视图ToolStripMenuItem
            // 
            this.刷新至初始视图ToolStripMenuItem.Name = "刷新至初始视图ToolStripMenuItem";
            this.刷新至初始视图ToolStripMenuItem.Size = new System.Drawing.Size(167, 26);
            this.刷新至初始视图ToolStripMenuItem.Text = "全图显示";
            this.刷新至初始视图ToolStripMenuItem.Click += new System.EventHandler(this.刷新至初始视图ToolStripMenuItem_Click);
            // 
            // 漫游ToolStripMenuItem
            // 
            this.漫游ToolStripMenuItem.Name = "漫游ToolStripMenuItem";
            this.漫游ToolStripMenuItem.Size = new System.Drawing.Size(53, 24);
            this.漫游ToolStripMenuItem.Text = "漫游";
            this.漫游ToolStripMenuItem.Click += new System.EventHandler(this.漫游ToolStripMenuItem_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 434);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Padding = new System.Windows.Forms.Padding(1, 0, 12, 0);
            this.statusStrip1.Size = new System.Drawing.Size(711, 26);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(84, 20);
            this.toolStripStatusLabel1.Text = "当前坐标：";
            // 
            // splitter1
            // 
            this.splitter1.Location = new System.Drawing.Point(0, 28);
            this.splitter1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(3, 406);
            this.splitter1.TabIndex = 3;
            this.splitter1.TabStop = false;
            // 
            // splitter2
            // 
            this.splitter2.Location = new System.Drawing.Point(360, 28);
            this.splitter2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.splitter2.Name = "splitter2";
            this.splitter2.Size = new System.Drawing.Size(9, 406);
            this.splitter2.TabIndex = 6;
            this.splitter2.TabStop = false;
            // 
            // axTOCControl2
            // 
            this.axTOCControl2.Dock = System.Windows.Forms.DockStyle.Left;
            this.axTOCControl2.Location = new System.Drawing.Point(3, 28);
            this.axTOCControl2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.axTOCControl2.Name = "axTOCControl2";
            this.axTOCControl2.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axTOCControl2.OcxState")));
            this.axTOCControl2.Size = new System.Drawing.Size(357, 406);
            this.axTOCControl2.TabIndex = 5;
            // 
            // axMapControl2
            // 
            this.axMapControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.axMapControl2.Location = new System.Drawing.Point(369, 28);
            this.axMapControl2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.axMapControl2.Name = "axMapControl2";
            this.axMapControl2.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axMapControl2.OcxState")));
            this.axMapControl2.Size = new System.Drawing.Size(342, 406);
            this.axMapControl2.TabIndex = 7;
            this.axMapControl2.OnMouseDown += new ESRI.ArcGIS.Controls.IMapControlEvents2_Ax_OnMouseDownEventHandler(this.axMapControl2_OnMouseDown);
            this.axMapControl2.OnMouseMove += new ESRI.ArcGIS.Controls.IMapControlEvents2_Ax_OnMouseMoveEventHandler(this.axMapControl1_OnMouseMove);
            this.axMapControl2.OnDoubleClick += new ESRI.ArcGIS.Controls.IMapControlEvents2_Ax_OnDoubleClickEventHandler(this.axMapControl1_OnDoubleClick);
            // 
            // axLicenseControl3
            // 
            this.axLicenseControl3.Enabled = true;
            this.axLicenseControl3.Location = new System.Drawing.Point(441, 384);
            this.axLicenseControl3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.axLicenseControl3.Name = "axLicenseControl3";
            this.axLicenseControl3.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axLicenseControl3.OcxState")));
            this.axLicenseControl3.Size = new System.Drawing.Size(32, 32);
            this.axLicenseControl3.TabIndex = 8;
            // 
            // 动态标注ToolStripMenuItem
            // 
            this.动态标注ToolStripMenuItem.Name = "动态标注ToolStripMenuItem";
            this.动态标注ToolStripMenuItem.Size = new System.Drawing.Size(83, 24);
            this.动态标注ToolStripMenuItem.Text = "动态标注";
            this.动态标注ToolStripMenuItem.Click += new System.EventHandler(this.动态标注ToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(711, 460);
            this.Controls.Add(this.axLicenseControl3);
            this.Controls.Add(this.axMapControl2);
            this.Controls.Add(this.splitter2);
            this.Controls.Add(this.axTOCControl2);
            this.Controls.Add(this.splitter1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axTOCControl2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axMapControl2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axLicenseControl3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 数据加载ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 加载地图文档ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 加载sho数据ToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripMenuItem 地图量测ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tsmiAreaMeasure;
        private System.Windows.Forms.ToolStripMenuItem 面积量测ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 查询ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 另存为ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 空间查询ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 数据查询ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 清除选择集ToolStripMenuItem;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.Splitter splitter2;
        private ESRI.ArcGIS.Controls.AxTOCControl axTOCControl2;
        private ESRI.ArcGIS.Controls.AxMapControl axMapControl2;
        private ESRI.ArcGIS.Controls.AxLicenseControl axLicenseControl3;
        private System.Windows.Forms.ToolStripMenuItem 清楚选择集ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 刷新至初始视图ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 漫游ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 动态标注ToolStripMenuItem;
    }
}

